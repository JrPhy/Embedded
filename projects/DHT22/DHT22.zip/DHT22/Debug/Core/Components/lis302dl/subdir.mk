################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Components/lis302dl/lis302dl.c 

OBJS += \
./Core/Components/lis302dl/lis302dl.o 

C_DEPS += \
./Core/Components/lis302dl/lis302dl.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Components/lis302dl/%.o Core/Components/lis302dl/%.su Core/Components/lis302dl/%.cyclo: ../Core/Components/lis302dl/%.c Core/Components/lis302dl/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F429xx -c -I../Core/Inc -I../USB_HOST/App -I../USB_HOST/Target -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Middlewares/ST/STM32_USB_Host_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Host_Library/Class/CDC/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Components-2f-lis302dl

clean-Core-2f-Components-2f-lis302dl:
	-$(RM) ./Core/Components/lis302dl/lis302dl.cyclo ./Core/Components/lis302dl/lis302dl.d ./Core/Components/lis302dl/lis302dl.o ./Core/Components/lis302dl/lis302dl.su

.PHONY: clean-Core-2f-Components-2f-lis302dl

