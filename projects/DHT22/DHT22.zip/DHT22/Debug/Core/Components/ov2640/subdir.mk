################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Components/ov2640/ov2640.c 

OBJS += \
./Core/Components/ov2640/ov2640.o 

C_DEPS += \
./Core/Components/ov2640/ov2640.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Components/ov2640/%.o Core/Components/ov2640/%.su Core/Components/ov2640/%.cyclo: ../Core/Components/ov2640/%.c Core/Components/ov2640/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F429xx -c -I../Core/Inc -I../USB_HOST/App -I../USB_HOST/Target -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Middlewares/ST/STM32_USB_Host_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Host_Library/Class/CDC/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Components-2f-ov2640

clean-Core-2f-Components-2f-ov2640:
	-$(RM) ./Core/Components/ov2640/ov2640.cyclo ./Core/Components/ov2640/ov2640.d ./Core/Components/ov2640/ov2640.o ./Core/Components/ov2640/ov2640.su

.PHONY: clean-Core-2f-Components-2f-ov2640

