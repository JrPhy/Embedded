/*
 * dht22.c
 *
 *  Created on: Apr 27, 2026
 *      Author: JR
 */
#include "stm32f4xx_hal.h"
#include "dht22.h"

volatile uint8_t dht22_ready = 0;  // 數據就緒旗標
uint8_t dht22_data[5];             // 儲存原始 5 Bytes 數據
extern TIM_HandleTypeDef htim1;

uint32_t last_tick = 0;
uint8_t bit_count = 0;
uint8_t data[5] = {0};

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    if (GPIO_Pin == GPIO_PIN_2) {
        // 獲取當前計時器數值 (假設 TIM1 每 1us 計數一次)
        uint32_t current_tick = __HAL_TIM_GET_COUNTER(&htim1);
        uint32_t duration = (current_tick >= last_tick) ?
                            (current_tick - last_tick) :
                            (0xFFFF - last_tick + current_tick);
        last_tick = current_tick;

        // 根據 duration 判斷時序
        if (duration > 100) {
            // 可能是 Start 或 Response 訊號，重置計數器
            bit_count = 0;
        } else if (duration > 20 && duration < 80) {
            // 進入數據位元判斷 (DHT22 的 Bit 傳輸大約在 50-70us)
            // 這裡可以根據 duration 長短來決定是 0 還是 1
            if (duration > 45) { // 經驗值：1 的高電位持續較久
                data[bit_count / 8] |= (1 << (7 - (bit_count % 8)));
            } else {
                data[bit_count / 8] &= ~(1 << (7 - (bit_count % 8)));
            }
            bit_count++;
        }
        if (bit_count >= 40) {     // 40 bits 接收完畢
			dht22_ready = 1;       // 舉手告訴主程式：可以顯示了！
			bit_count = 0;         // 重置準備下一輪
		}
    }
}

uint8_t DHT22_Get_Data(float *temp, float *humi) {
    // 如果中斷還沒收完 40 bits，直接跳出
    if (!dht22_ready)  return 0;
    // --- 進入臨界區 (Critical Section) ---
    // 讀取數據前關閉 EXTI 中斷，防止處理到一半數據被新的一輪通訊蓋掉
    HAL_NVIC_DisableIRQ(EXTI2_IRQn);

    uint8_t status = 0;
    uint8_t check_sum = dht22_data[4];

    // 執行 Checksum 校驗 (前四個 Byte 相加之和的低 8 位)
    if (check_sum == ((dht22_data[0] + dht22_data[1] + dht22_data[2] + dht22_data[3]) & 0xFF)) {

        // 解析濕度 (MSB << 8 | LSB)
        uint16_t rh_raw = (dht22_data[0] << 8) | dht22_data[1];
        *humi = (float)rh_raw / 10.0f;

        // 解析溫度 (MSB << 8 | LSB)
        uint16_t t_raw = (dht22_data[2] << 8) | dht22_data[3];

        // DHT22 溫度格式：Bit 15 為 1 代表負溫，0 代表正溫
        if (t_raw & 0x8000) {
            *temp = (float)(t_raw & 0x7FFF) / -10.0f;
        } else {
            *temp = (float)t_raw / 10.0f;
        }

        status = 1; // 校驗成功
    } else {
        status = 0; // 校驗失敗 (可能環境雜訊干擾)
    }

    // 重置旗標，準備接收下一輪數據
    dht22_ready = 0;

    // --- 離開臨界區 ---
    HAL_NVIC_EnableIRQ(EXTI2_IRQn);

    return status;
}

void delay_us (uint16_t us) {
    __HAL_TIM_SET_COUNTER(&htim1, 0);
    while (__HAL_TIM_GET_COUNTER(&htim1) < us);
}

void DHT22_Start (void) {
    HAL_GPIO_WritePin(DHT22_PORT, DHT22_PIN, GPIO_PIN_RESET); // 拉低
    HAL_Delay(20);
    HAL_GPIO_WritePin(DHT22_PORT, DHT22_PIN, GPIO_PIN_SET);   // 釋放
    delay_us(30);
}

uint8_t DHT22_Check_Response (void) {
    uint8_t Response = 0;
    uint16_t timeout = 0;

    delay_us(40);
    if (!(HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN))) {
        delay_us(80);
        if ((HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN))) Response = 1;
        else Response = 0;
    }

    // 防卡死處理：加上 timeout
    timeout = 0;
    while ((HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN))) {
        timeout++;
        if (timeout > 10000) break; // 如果超過一段時間沒變低，強制跳出
    }

    return Response;
}

uint8_t DHT22_Read_Byte (void) {
    uint8_t i = 0;
    for (int j=0; j<8; j++) {
        uint32_t timeout = 0;

        timeout = 0;
        while (!(HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN))) {
            if (++timeout > 10000) return 0; // 超時跳出
        }

        delay_us(40);

        // 3. 判斷電平
        if (!(HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN))) {
            i &= ~(1 << (7 - j)); // 0
        } else {
            i |= (1 << (7 - j));  // 1

            // 4. 如果是 1 (高電位)，必須等它變回低電位，否則會影響下一個 Bit
            timeout = 0;
            while (HAL_GPIO_ReadPin(DHT22_PORT, DHT22_PIN)) {
                if (++timeout > 10000) return 0;
            }
        }
    }
    return i;
}
