/*
 * dht22.h
 *
 *  Created on: Apr 27, 2026
 *      Author: JR
 */

#ifndef INC_DHT22_H_
#define INC_DHT22_H_

#define DHT22_PORT GPIOE
#define DHT22_PIN  GPIO_PIN_2

void delay_us (uint16_t us);
void DHT22_Start (void);
uint8_t DHT22_Check_Response (void);
uint8_t DHT22_Read_Byte (void);
uint8_t DHT22_Get_Data(float *temp, float *humi);
#endif /* INC_DHT22_H_ */
