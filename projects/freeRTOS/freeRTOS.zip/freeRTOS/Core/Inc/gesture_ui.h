#ifndef __GESTURE_UI_H
#define __GESTURE_UI_H

#include "cmsis_os.h"
#include "stm32f429i_discovery.h"
#include "stm32f429i_discovery_lcd.h"
#include "stm32f429i_discovery_ts.h"
#include <stdbool.h>
/* SDRAM 起始位址 (Bank 2) */
#define SDRAM_DEVICE_ADDR         ((uint32_t)0xD0000000)

/* LCD 顯存起始位址：直接設在 SDRAM 的開頭 */
#define LCD_FB_START_ADDRESS      SDRAM_DEVICE_ADDR

/* 額外補充：如果你之後要用雙緩衝 (Double Buffer) */
/* 240 * 320 * 2 (16-bit color) = 153,600 bytes */
#define LCD_FB_OFFSET             ((uint32_t)0x30000)
#define LCD_FB_SECOND_ADDRESS     (LCD_FB_START_ADDRESS + LCD_FB_OFFSET)
/* 分頁枚舉 */
typedef enum {
    PAGE_AIR = 0,
    PAGE_WEATHER,
    PAGE_MAX
} Page_t;

/* 手勢枚舉 */
typedef enum {
    GESTURE_NONE,
    GESTURE_LEFT,
    GESTURE_RIGHT
} Gesture_t;

/* 初始化函式：包含硬體與 Queue 建立 */
void UI_System_Init(void);

/* 任務函式原型：需在 main 或 freertos.c 中啟動執行緒 */
void StartGestureTask(void *argument);
void StartUITask(void *argument);

#endif /* __GESTURE_UI_H */
