#include "gesture_ui.h"

/* 內部使用的 Queue 句柄 */
osMessageQueueId_t gestureQueueHandle;

/* ------------------------------------------------------------------
 * 初始化硬體與 RTOS 物件
 * ------------------------------------------------------------------ */
void UI_System_Init(void) {
    // 初始化 LCD
    BSP_LCD_Init();
    BSP_LCD_LayerDefaultInit(0, LCD_FB_START_ADDRESS);
    BSP_LCD_SelectLayer(0);
    BSP_LCD_DisplayOn();
    BSP_LCD_SetBackColor(LCD_COLOR_BLACK);
    // 初始化觸控螢幕 (240x320)
    if (BSP_TS_Init(240, 320) != TS_OK) {
    	BSP_LCD_DisplayStringAt(0, 100, (uint8_t*) "BSP_TS_Init(240, 320) != TS_OK", CENTER_MODE);
    }

    // 建立訊息隊列 (Queue)
    gestureQueueHandle = osMessageQueueNew(5, sizeof(Gesture_t), NULL);
}

/* ------------------------------------------------------------------
 * 內部繪圖函式 (Render)
 * ------------------------------------------------------------------ */
static void RenderPage(Page_t page) {
	BSP_LCD_Clear(LCD_COLOR_BLACK);

	/* 2. 設定文字顏色為白色，背景為黑色（透明感） */
	BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
	BSP_LCD_SetBackColor(LCD_COLOR_BLACK);
	BSP_LCD_SetFont(&Font16);

    if (page == PAGE_AIR) {
        BSP_LCD_SetBackColor(LCD_COLOR_LIGHTGREEN);
        BSP_LCD_DisplayStringAt(0, 50, (uint8_t*)"  AIR QUALITY  ", CENTER_MODE);
        BSP_LCD_DisplayStringAt(0, 120, (uint8_t*)"PM2.5: 25 ug/m3", CENTER_MODE);
    } else {
        BSP_LCD_SetBackColor(LCD_COLOR_LIGHTBLUE);
        BSP_LCD_DisplayStringAt(0, 50, (uint8_t*)"  WEATHER INFO  ", CENTER_MODE);
        BSP_LCD_DisplayStringAt(0, 120, (uint8_t*)"Temp: 26.5 C", CENTER_MODE);
    }

    BSP_LCD_SetBackColor(LCD_COLOR_BLACK);
    BSP_LCD_DisplayStringAt(0, 280, (uint8_t*)"< Swipe to Switch >", CENTER_MODE);
}

/* ------------------------------------------------------------------
 * 手勢偵測任務 (Producer)
 * ------------------------------------------------------------------ */
void StartGestureTask(void *argument) {
    TS_StateTypeDef TS_State;
    int16_t startX = 0;
    bool isPressed = false;

    for(;;) {
        BSP_TS_GetState(&TS_State);

        if (TS_State.TouchDetected) {
            if (!isPressed) {
                startX = TS_State.X;
                isPressed = true;
                BSP_LCD_DisplayStringAt(0, 280, (uint8_t*)"TouchDetected", CENTER_MODE);
            }
        } else {
            if (isPressed) {
                int16_t deltaX = TS_State.X - startX;
                Gesture_t gesture = GESTURE_NONE;
                // 門檻值 60 像素
                if (deltaX > 20)       gesture = GESTURE_RIGHT;
                else if (deltaX < -30) gesture = GESTURE_LEFT;

                BSP_LCD_DisplayStringAt(0, 280, (uint8_t*)"gesture", CENTER_MODE);
                if (gesture != GESTURE_NONE) {
                    osMessageQueuePut(gestureQueueHandle, &gesture, 0U, 0U);
                }
                isPressed = false;
            }
        }
        osDelay(30);
    }
}

/* ------------------------------------------------------------------
 * UI 渲染任務 (Consumer)
 * ------------------------------------------------------------------ */
void StartUITask(void *argument) {
    Page_t currentPage = PAGE_AIR;
    Gesture_t receivedGesture;

    RenderPage(currentPage);

    for(;;) {
        if (osMessageQueueGet(gestureQueueHandle, &receivedGesture, NULL, osWaitForever) == osOK) {
            if (receivedGesture == GESTURE_LEFT) {
                currentPage = (currentPage + 1) % PAGE_MAX;
            } else if (receivedGesture == GESTURE_RIGHT) {
                currentPage = (currentPage == 0) ? PAGE_MAX - 1 : currentPage - 1;
            }
            RenderPage(currentPage);
        }
    }
}
