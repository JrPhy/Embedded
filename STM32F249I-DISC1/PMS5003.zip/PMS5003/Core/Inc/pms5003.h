/*
 * pms5003.h
 *
 *  Created on: Jan 30, 2026
 *      Author: JR
 */

#ifndef INC_PMS5003_H_
#define INC_PMS5003_H_

#include "main.h"

/* Private user code ---------------------------------------------------------*/
typedef struct {
    uint16_t pm10_std, pm25_std, pm100_std; // 標準顆粒物
    uint16_t pm10_env, pm25_env, pm100_env; // 大氣環境 (常用)
} PMS5003_Data;


// 外部宣告，讓 main.c 可以讀取
extern PMS5003_Data pms_data;
extern uint8_t rx_buf[32];     // 接收緩衝區
extern volatile uint8_t data_ready; // 數據更新旗標
// 函數宣告
uint8_t PMS5003_Parse(uint8_t* buf, PMS5003_Data *data);

#endif /* INC_PMS5003_H_ */
