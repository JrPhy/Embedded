/*
 * pms5003.c
 *
 *  Created on: Jan 31, 2026
 *      Author: JR
 */


#include "main.h"
#include "pms5003.h"

uint8_t PMS5003_Parse(uint8_t *buf, PMS5003_Data *data) {
    // 1. 检查起始符
    if (buf[0] != 0x42 || buf[1] != 0x4D) return -1;

    // 2. 计算校验和 (前30字节之和)
    uint16_t check_sum = 0;
    for (int i = 0; i < 30; i++) {
        check_sum += buf[i];
    }

    // 3. 比对校验和
    uint16_t received_sum = (buf[30] << 8) | buf[31];
    if (check_sum != received_sum) return -2;

    // 4. 解析数据 (均为大端模式)
    data->pm10_std = (buf[4] << 8)  | buf[5];
    data->pm25_std = (buf[6] << 8)  | buf[7];
    data->pm100_std  = (buf[8] << 8)  | buf[9];

    data->pm10_env = (buf[10] << 8) | buf[11];
    data->pm25_env = (buf[12] << 8) | buf[13];
    data->pm100_env  = (buf[14] << 8) | buf[15];

    return 0; // 解析成功
}
